# Badger Badger, Honey Badger!
## The official Honey Badger extension for Reddit - browse top posts from random subreddit 

![...not!](./important.png)

1. Install the extension from Chrome Web Store
2. Visit [https://reddit.com](https://reddit.com)
3. Hit `Shift` three times (_or press the Mysterious Magical Blue Button™_) to see top post from a new random Subreddit.

![Trololo](./foo.gif)
![Trololo](./foo.gif)
![Trololo](./foo.gif)
![Trololo](./foo.gif)
![Trololo](./foo.gif)

![Honey Badger](./honey-badger.jpg)

![Trololo](./foo.gif)
![Trololo](./foo.gif)
![Trololo](./foo.gif)
![Trololo](./foo.gif)
![Trololo](./foo.gif)

